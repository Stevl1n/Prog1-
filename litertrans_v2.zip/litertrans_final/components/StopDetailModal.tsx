import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {
  Colors,
  TransportColors,
  TransportIcons,
  TransportShortLabels,
} from '../constants/Colors';
import { Arrival, Stop, TransportService } from '../data/TransportService';

interface Props {
  stop: Stop | null;
  onClose: () => void;
}

function formatEta(seconds: number, minutes: number) {
  const sec = Math.max(0, seconds || minutes * 60);
  if (sec < 60) return `${sec} с`;
  if (sec >= 60 * 60) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    return `${h} ч ${m.toString().padStart(2, '0')} мин`;
  }
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m} мин ${s.toString().padStart(2, '0')} с`;
}

export default function StopDetailModal({ stop, onClose }: Props) {
  const [arrivals, setArrivals] = useState<Arrival[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!stop) return;
    setArrivals([]);

    const ac = new AbortController();

    const tick = (showSpinner: boolean) => {
      if (showSpinner) setLoading(true);
      TransportService.fetchLiveArrivals(stop, 220, { signal: ac.signal })
        .then(items => {
          if (!ac.signal.aborted) setArrivals(items);
        })
        .catch((e: unknown) => {
          const err = e as { name?: string };
          if (err?.name === 'AbortError' || ac.signal.aborted) return;
        })
        .finally(() => {
          if (showSpinner && !ac.signal.aborted) setLoading(false);
        });
    };

    tick(true);
    const id = setInterval(() => tick(false), 5000);

    return () => {
      ac.abort();
      clearInterval(id);
    };
  }, [stop?.id]);

  if (!stop) return null;

  return (
    <Modal
      visible={!!stop}
      transparent
      animationType="slide"
      onRequestClose={onClose}
    >
      {/* Затемнение */}
      <Pressable style={styles.overlay} onPress={onClose} />

      <View style={styles.sheet}>
        {/* Ручка */}
        <View style={styles.handle} />

        <ScrollView showsVerticalScrollIndicator={false}>
          {/* Заголовок */}
          <View style={styles.header}>
            <Pressable
              style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}
              onPress={onClose}
            >
              <MaterialCommunityIcons name="chevron-left" size={20} color="#fff" />
              <Text style={styles.backText}>Назад</Text>
            </Pressable>
            <Pressable style={({ pressed }) => [pressed && { opacity: 0.7 }]}>
              <MaterialCommunityIcons
                name="heart-outline"
                size={22}
                color={Colors.orange}
              />
            </Pressable>
          </View>

          {/* Информация об остановке */}
          <View style={styles.stopInfo}>
            <Text style={styles.stopLabel}>Остановка</Text>
            <Text style={styles.stopName}>{stop.name}</Text>
            <View style={styles.addressRow}>
              <MaterialCommunityIcons
                name="map-marker"
                size={12}
                color={Colors.purple}
              />
              <Text style={styles.address}>{stop.address}</Text>
            </View>
            {stop.routes.length > 0 && (
              <Text style={styles.routesList}>
                {'Маршруты: '}
                {stop.routes.slice(0, 12).join(', ')}
                {stop.routes.length > 12 ? '…' : ''}
              </Text>
            )}
          </View>

          <Text style={styles.sectionTitle}>Ближайший транспорт</Text>

          {/* Загрузка */}
          {loading && arrivals.length === 0 && (
            <View style={styles.emptyWrap}>
              <ActivityIndicator color={Colors.orange} />
              <Text style={styles.emptyText}>Загрузка...</Text>
            </View>
          )}

          {/* Нет прибытий */}
          {!loading && arrivals.length === 0 && (
            <View style={styles.emptyWrap}>
              <MaterialCommunityIcons
                name="clock-outline"
                size={24}
                color={Colors.textSecondary}
              />
              <Text style={styles.emptyText}>Нет ближайших прибытий</Text>
            </View>
          )}

          {/* Список прибытий */}
          {arrivals.map(arr => (
            <View key={arr.id} style={styles.arrivalRow}>
              {/* Иконка транспорта */}
              <View
                style={[
                  styles.arrivalIcon,
                  {
                    backgroundColor:
                      TransportColors[arr.vehicle.type || 'bus'],
                  },
                ]}
              >
                <MaterialCommunityIcons
                  name={
                    (TransportIcons[arr.vehicle.type || 'bus'] as any) || 'bus'
                  }
                  size={20}
                  color="#fff"
                />
              </View>

              {/* Маршрут + тип + загрузка */}
              <View style={{ flex: 1 }}>
                <Text style={styles.arrivalRoute}>
                  ⚡{String(arr.vehicle.routeNumber).trim() || '—'}
                </Text>
                <Text style={styles.arrivalTypeHint}>
                  {TransportShortLabels[arr.vehicle.type || 'bus'] || 'авт.'}
                </Text>
                <Text
                  style={[
                    styles.arrivalOccupancy,
                    {
                      color: TransportService.getOccupancyColor(
                        arr.vehicle.occupancy,
                      ),
                    },
                  ]}
                >
                  {TransportService.getOccupancyLabel(arr.vehicle.occupancy)}
                </Text>
              </View>

              {/* Правая часть: Live-бейдж + время */}
              <View style={{ alignItems: 'flex-end', gap: 4 }}>
                {arr.rawType === 'realtime' && (
                  <View style={styles.realtimeBadge}>
                    <Text style={styles.realtimeBadgeText}>Live</Text>
                  </View>
                )}
                <Text
                  style={[
                    styles.arrivalTime,
                    (arr.secondsUntilArrival ?? 9999) <= 180 && {
                      color: Colors.orange,
                    },
                  ]}
                >
                  {(arr.secondsUntilArrival ?? 0) <= 15
                    ? 'Прибывает'
                    : formatEta(
                        arr.secondsUntilArrival ?? 0,
                        arr.minutesUntilArrival,
                      )}
                </Text>
              </View>
            </View>
          ))}

          <View style={{ height: 32 }} />
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1 },
  sheet: {
    backgroundColor: Colors.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderTopWidth: 3,
    borderTopColor: Colors.orange,
    maxHeight: '80%',
    paddingBottom: 32,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.separator,
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 4,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  backText: { fontSize: 16, color: '#fff' },

  stopInfo: { paddingHorizontal: 20, paddingBottom: 16 },
  stopLabel: { fontSize: 14, color: Colors.textSecondary, marginBottom: 2 },
  stopName: { fontSize: 26, fontWeight: '700', color: '#fff', marginBottom: 4 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 4 },
  address: { fontSize: 13, color: Colors.textSecondary },
  routesList: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },

  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    paddingHorizontal: 20,
    marginBottom: 12,
  },

  arrivalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.card2,
    borderRadius: 16,
    padding: 14,
    marginHorizontal: 20,
    marginBottom: 8,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  arrivalIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  arrivalRoute: { fontSize: 16, fontWeight: '700', color: '#fff' },
  arrivalTypeHint: {
    fontSize: 12,
    color: Colors.textSecondary,
    fontWeight: '600',
    marginTop: 2,
  },
  arrivalOccupancy: { fontSize: 12, marginTop: 2 },

  realtimeBadge: {
    backgroundColor: 'rgba(52,199,89,0.18)',
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  realtimeBadgeText: { fontSize: 10, color: '#34C759', fontWeight: '700' },

  arrivalTime: { fontSize: 16, fontWeight: '700', color: '#fff' },

  emptyWrap: {
    marginHorizontal: 20,
    marginBottom: 8,
    paddingVertical: 20,
    alignItems: 'center',
    gap: 10,
  },
  emptyText: { color: Colors.textSecondary, fontSize: 13, fontWeight: '600' },
});
