import React, { createContext, useContext, useMemo, useState } from 'react';

type AppSettings = {
  showAllStopsOnMap: boolean;
};

type AppSettingsContextValue = {
  settings: AppSettings;
  setShowAllStopsOnMap: (value: boolean) => void;
};

const AppSettingsContext = createContext<AppSettingsContextValue | null>(null);

export function AppSettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>({
    showAllStopsOnMap: true,
  });

  const value = useMemo(
    () => ({
      settings,
      setShowAllStopsOnMap: (value: boolean) => {
        setSettings(prev => ({ ...prev, showAllStopsOnMap: value }));
      },
    }),
    [settings],
  );

  return <AppSettingsContext.Provider value={value}>{children}</AppSettingsContext.Provider>;
}

export function useAppSettings() {
  const context = useContext(AppSettingsContext);
  if (!context) {
    throw new Error('useAppSettings must be used within AppSettingsProvider');
  }
  return context;
}
