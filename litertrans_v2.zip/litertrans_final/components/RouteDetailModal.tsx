import React from 'react';
import { View, Text, StyleSheet, Modal, TouchableOpacity, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors, TransportLabels } from '../constants/Colors';
import { Route } from '../data/TransportService';

interface Props {
  route: Route | null;
  onClose: () => void;
}

export default function RouteDetailModal({ route, onClose }: Props) {
  if (!route) return null;

  return (
    <Modal visible={!!route} transparent animationType="slide" onRequestClose={onClose}>
      <TouchableOpacity style={styles.overlay} activeOpacity={1} onPress={onClose} />
      <View style={styles.sheet}>
        <View style={styles.handle} />
        <View style={styles.header}>
          <TouchableOpacity style={styles.backBtn} onPress={onClose}>
            <MaterialCommunityIcons name="chevron-left" size={20} color="#fff" />
            <Text style={styles.backText}>Назад</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.routeHeader}>
          <View style={[styles.routeIconLarge, { backgroundColor: route.color }]}>
            <MaterialCommunityIcons name="bus" size={28} color="#fff" />
          </View>
          <View>
            <Text style={styles.routeNumber}>Маршрут №{route.number}</Text>
            <Text style={styles.routeName}>{route.name}</Text>
            <Text style={styles.routeType}>{TransportLabels[route.type]}</Text>
          </View>
        </View>
        <ScrollView showsVerticalScrollIndicator={false}>
          <Text style={styles.sectionTitle}>Остановки маршрута</Text>
          {route.stops.map((stop, idx) => (
            <View key={stop.id} style={styles.stopRow}>
              <View style={styles.timeline}>
                <View style={[styles.dot, { backgroundColor: idx === 0 || idx === route.stops.length - 1 ? route.color : Colors.separator }]} />
                {idx < route.stops.length - 1 && <View style={[styles.line, { backgroundColor: route.color + '40' }]} />}
              </View>
              <View style={styles.stopInfo}>
                <Text style={[styles.stopName, (idx === 0 || idx === route.stops.length - 1) && { color: route.color }]}>{stop.name}</Text>
                <Text style={styles.stopAddress}>{stop.address}</Text>
              </View>
            </View>
          ))}
          <View style={{ height: 48 }} />
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1 },
  sheet: { backgroundColor: Colors.card, borderTopLeftRadius: 24, borderTopRightRadius: 24, maxHeight: '85%', paddingBottom: 16 },
  handle: { width: 40, height: 4, borderRadius: 2, backgroundColor: Colors.separator, alignSelf: 'center', marginTop: 12, marginBottom: 4 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 12 },
  backBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  backText: { fontSize: 16, color: '#fff' },
  routeHeader: { flexDirection: 'row', alignItems: 'center', gap: 16, paddingHorizontal: 20, paddingBottom: 20 },
  routeIconLarge: { width: 60, height: 60, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  routeNumber: { fontSize: 22, fontWeight: '700', color: '#fff' },
  routeName: { fontSize: 14, color: Colors.textSecondary, marginTop: 2 },
  routeType: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  sectionTitle: { fontSize: 18, fontWeight: '600', color: '#fff', paddingHorizontal: 20, marginBottom: 8 },
  stopRow: { flexDirection: 'row', paddingLeft: 20 },
  timeline: { width: 24, alignItems: 'center' },
  dot: { width: 10, height: 10, borderRadius: 5, marginTop: 5 },
  line: { width: 2, flex: 1, minHeight: 30 },
  stopInfo: { flex: 1, paddingLeft: 12, paddingBottom: 16, paddingRight: 20 },
  stopName: { fontSize: 15, fontWeight: '600', color: '#fff' },
  stopAddress: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
});
