// Цветовая палитра ЛитерТранс

export const Colors = {
  orange: '#FF6B1A',
  orangeLight: '#FF8C42',
  purple: '#7B2FFF',
  purpleLight: '#9B59FF',
  bg: '#0D0D0D',
  card: '#1A1A1A',
  card2: '#252525',
  textPrimary: '#FFFFFF',
  textSecondary: '#8E8E93',
  separator: '#2C2C2E',
  red: '#FF3B30',
  green: '#34C759',
  blue: '#007AFF',
  teal: '#5AC8FA',
};

/**
 * Цвет фона маркера/иконки по типу транспорта.
 * metro отличается от tram, чтобы было визуально понятно.
 */
export const TransportColors: Record<string, string> = {
  bus: Colors.orange,
  tram: '#FF3B30',        // красный
  trolleybus: '#007AFF',  // синий
  minibus: Colors.purple, // фиолетовый
  metro: '#AF52DE',       // пурпурный (отличается от tram)
};

/**
 * Иконки MaterialCommunityIcons по типу транспорта.
 */
export const TransportIcons: Record<string, string> = {
  bus: 'bus',
  tram: 'train-car',
  trolleybus: 'bus-electric',
  minibus: 'van-passenger',
  metro: 'subway',
};

/**
 * Полные метки для типов транспорта.
 */
export const TransportLabels: Record<string, string> = {
  bus: 'Автобус',
  tram: 'Трамвай',
  trolleybus: 'Троллейбус',
  minibus: 'Маршрутка',
  metro: 'Метро',
};

/**
 * Короткая подпись к номеру маршрута (не путать с «одним автобусом»).
 */
export const TransportShortLabels: Record<string, string> = {
  bus: 'авт.',
  tram: 'трам.',
  trolleybus: 'тролл.',
  minibus: 'марш.',
  metro: 'метро',
};
