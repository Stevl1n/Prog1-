/** Как в testitdbot — стартовая область карты и ID для /live. */
export const DEFAULT_STOP = {
  lat: 59.826193,
  lon: 30.409437,
} as const;
