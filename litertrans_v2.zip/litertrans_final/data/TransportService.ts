import {
  fetchLiveBoardAuto,
  fetchNearestStopIdsAuto,
  fetchStopsInBboxAuto,
  fetchVehiclesInBboxAuto,
  getBridgeBaseUrl,
  getBridgeCandidateBases,
  resetBridgeRouting,
  searchStopsAuto,
  bridgeFetchJson,
  fetchBridgeHealthAuto,
  type BridgeArrival,
  type BridgeHealth,
  type BridgeVehicle,
  type SearchStopItem,
} from './bridge';

// ─── Модели ──────────────────────────────────────────────────────────────────

export interface Stop {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  isFavorite: boolean;
  routes: string[];
  stopIds?: string[];
  type?: TransportType;
  source?: string;
  links?: StopLinks;
}

export interface StopLinks {
  gtfs_feed: string;
  transportspb_stop_page: string;
  transportspb_all_stops_map: string;
  map_2gis: string;
  map_yandex: string;
  busti_all: string;
  busti_trolleybus: string;
  busti_tram: string;
  route_links: Array<{
    route: string;
    schedule_url: string;
    map_url: string;
  }>;
}

export type TransportType = 'bus' | 'tram' | 'trolleybus' | 'minibus' | 'metro';
export type OccupancyLevel = 'empty' | 'normal' | 'crowded' | 'full';
export type CityRegion = 'spb' | 'lenobl';

export interface Route {
  id: string;
  number: string;
  name: string;
  type: TransportType;
  stops: Stop[];
  isFavorite: boolean;
  color: string;
}

export interface Vehicle {
  id: string;
  routeId: string;
  routeNumber: string;
  type: TransportType;
  latitude: number;
  longitude: number;
  bearing: number;
  arrivalMinutes: number;
  occupancy: OccupancyLevel;
}

export interface Arrival {
  id: string;
  vehicle: Vehicle;
  stopId: string;
  minutesUntilArrival: number;
  secondsUntilArrival?: number;
  rawType?: 'realtime' | 'schedule';
  confidence?: number;
  sourceCount?: number;
}

export interface SavedRoute {
  id: string;
  fromName: string;
  toName: string;
  color: string;
}

export interface Trip {
  id: string;
  routeNumber: string;
  fromStop: string;
  toStop: string;
  date: string;
  duration: number;
}

export type { BridgeHealth, BridgeArrival };

// ─── Вспомогательные ─────────────────────────────────────────────────────────

/**
 * Маппинг stop_kind → TransportType.
 * Порядок проверок важен: 'trolley' должна идти до 'bus'.
 */
function mapStopKind(rawKind?: string): TransportType {
  const value = (rawKind || '').toLowerCase();
  if (value.includes('tram')) return 'tram';
  if (value.includes('trolley')) return 'trolleybus';
  if (value.includes('metro') || value.includes('subway')) return 'metro';
  if (value.includes('mini') || value.includes('van')) return 'minibus';
  return 'bus';
}

/**
 * Маппинг transport_type из данных о транспортных средствах → TransportType.
 */
function mapTransportType(rawType?: string): TransportType {
  const value = (rawType || '').toLowerCase();
  if (value.includes('tram')) return 'tram';
  if (value.includes('trolley')) return 'trolleybus';
  if (value.includes('metro') || value.includes('subway')) return 'metro';
  if (value.includes('mini') || value.includes('van')) return 'minibus';
  if (value.includes('electric_bus') || value.includes('electric')) return 'bus';
  return 'bus';
}

/**
 * Конвертирует DTO из bridge → внутреннюю модель Stop.
 * Обрабатывает все возможные форматы поля stop_id/stop_ids/canonical_id.
 */
function mapDtoToStop(item: SearchStopItem, idPrefix: string, idx: number): Stop {
  // Нормализуем stopIds — берём все доступные идентификаторы
  const rawStopIds: string[] = [];
  if (Array.isArray(item.stop_ids) && item.stop_ids.length > 0) {
    rawStopIds.push(...item.stop_ids.map(String));
  } else if (item.stop_id != null && String(item.stop_id).trim() !== '') {
    rawStopIds.push(String(item.stop_id));
  }

  // Дедупликация stopIds
  const stopIds = [...new Set(rawStopIds)];

  // Нормализуем маршруты — убираем пустые строки и дубликаты
  const routes = item.routes?.length
    ? [...new Set(item.routes.map(r => r.trim()).filter(Boolean))]
    : [];

  return {
    id: item.canonical_id || item.stop_id || `${idPrefix}_${idx}`,
    name: item.title?.trim() || 'Остановка',
    address: item.subtitle?.trim() || 'Санкт-Петербург',
    latitude: item.lat,
    longitude: item.lon,
    isFavorite: false,
    routes,
    type: mapStopKind(item.stop_kind),
    source: item.source,
    links: (item as SearchStopItem & { links?: Stop['links'] }).links,
    stopIds,
  };
}

// ─── Сервис ───────────────────────────────────────────────────────────────────

export const TransportService = {
  distanceMeters(aLat: number, aLon: number, bLat: number, bLon: number): number {
    const r = 6371000;
    const dLat = ((bLat - aLat) * Math.PI) / 180;
    const dLon = ((bLon - aLon) * Math.PI) / 180;
    const x =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((aLat * Math.PI) / 180) *
        Math.cos((bLat * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const y = 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
    return r * y;
  },

  /**
   * Кэш остановок: ключ — bbox + limit, TTL 4.5 с.
   * При cache miss — запрашиваем сеть.
   */
  stopsCache: new Map<string, { ts: number; data: Stop[] }>(),
  vehiclesCache: new Map<string, { ts: number; data: Vehicle[] }>(),

  mapStopKind,
  mapTransportType,

  getBridgeBaseUrl(): string {
    return getBridgeBaseUrl();
  },

  getBridgeCandidates(): string[] {
    return getBridgeCandidateBases();
  },

  resetBridgeRouting(): void {
    resetBridgeRouting();
  },

  async fetchJsonFromBridge<T>(path: string): Promise<T> {
    return bridgeFetchJson<T>(path);
  },

  async fetchBridgeHealth(): Promise<BridgeHealth> {
    return fetchBridgeHealthAuto();
  },

  async fetchStopsInBbox(
    bbox: { south: number; west: number; north: number; east: number },
    limit = 1200,
  ): Promise<Stop[]> {
    const cacheKey = `s:${bbox.south.toFixed(4)}:${bbox.west.toFixed(4)}:${bbox.north.toFixed(4)}:${bbox.east.toFixed(4)}:${limit}`;
    const cached = this.stopsCache.get(cacheKey);
    if (cached && Date.now() - cached.ts < 4500) {
      return cached.data;
    }

    const data = await fetchStopsInBboxAuto(bbox, limit);
    const mapped = (data.items ?? []).map((item, idx) =>
      mapDtoToStop(item, 'bridge_stop', idx),
    );

    this.stopsCache.set(cacheKey, { ts: Date.now(), data: mapped });
    return mapped;
  },

  async searchBridgeStops(query: string, limit = 16): Promise<Stop[]> {
    const data = await searchStopsAuto(query, limit);
    return (data.items ?? []).map((item, idx) => mapDtoToStop(item, 'search_stop', idx));
  },

  async fetchVehiclesInBbox(
    bbox: { south: number; west: number; north: number; east: number },
    limit = 1500,
  ): Promise<Vehicle[]> {
    const cacheKey = `v:${bbox.south.toFixed(4)}:${bbox.west.toFixed(4)}:${bbox.north.toFixed(4)}:${bbox.east.toFixed(4)}:${limit}`;
    const cached = this.vehiclesCache.get(cacheKey);
    // Короткий TTL: при опросе каждые 5 с не отдаём снимок старше 3.5 с
    if (cached && Date.now() - cached.ts < 3500) {
      return cached.data;
    }

    const data = await fetchVehiclesInBboxAuto(bbox, limit);
    const mapped: Vehicle[] = (data.vehicles ?? []).map((v: BridgeVehicle) => ({
      id: v.vehicle_id,
      routeId: v.route || v.route_number || v.vehicle_id,
      routeNumber: v.route_number || v.route || '—',
      type: mapTransportType(v.transport_type),
      latitude: v.lat,
      longitude: v.lon,
      bearing: v.bearing ?? 0,
      arrivalMinutes: 0,
      occupancy: 'normal' as OccupancyLevel,
    }));

    if (mapped.length > 0) {
      this.vehiclesCache.set(cacheKey, { ts: Date.now(), data: mapped });
    }
    return mapped;
  },

  /**
   * Если у остановки нет stop_ids — пробуем найти их через nearest-stop-ids,
   * затем через поиск по имени (fallback).
   * Возвращает обогащённую копию объекта Stop.
   */
  async resolveStopForEta(stop: Stop): Promise<Stop> {
    if ((stop.stopIds ?? []).length > 0) {
      return stop;
    }

    // Попытка 1: nearest-stop-ids по координатам
    try {
      const cluster = await this.fetchNearestStopCluster(stop.latitude, stop.longitude, 8);
      if (cluster && cluster.stopIds.length > 0) {
        return {
          ...stop,
          stopIds: cluster.stopIds,
          latitude: cluster.lat,
          longitude: cluster.lon,
        };
      }
    } catch {
      // игнорируем, пробуем дальше
    }

    // Попытка 2: поиск по имени
    const candidates = await this.searchBridgeStops(stop.name, 8);
    if (candidates.length === 0) return stop;

    const withIds = candidates.filter(item => (item.stopIds ?? []).length > 0);
    if (withIds.length === 0) return stop;

    withIds.sort(
      (a, b) =>
        this.distanceMeters(stop.latitude, stop.longitude, a.latitude, a.longitude) -
        this.distanceMeters(stop.latitude, stop.longitude, b.latitude, b.longitude),
    );

    const nearest = withIds[0];
    const dist = this.distanceMeters(
      stop.latitude,
      stop.longitude,
      nearest.latitude,
      nearest.longitude,
    );
    // Принимаем только если остановка не дальше 500 м
    return dist <= 500 ? nearest : stop;
  },

  /**
   * Нормализация ETA в секунды.
   * Обрабатывает миллисекунды (> 100 000) и отрицательные значения.
   */
  normalizeEtaSeconds(raw: number): number {
    if (!Number.isFinite(raw)) return 0;
    if (raw < 0) return 0;
    // Вероятно миллисекунды
    if (raw > 100000) return Math.floor(raw / 1000);
    return Math.floor(raw);
  },

  isReasonableEta(seconds: number): boolean {
    // Отбрасываем ETA > 24 ч и < 0
    return seconds >= 0 && seconds <= 24 * 60 * 60;
  },

  /**
   * Нормализация номера маршрута: убираем символ ⚡ (электробус), пробелы, дефисы.
   * Возвращает UPPER-CASE строку без пробелов, пустую строку если нечего нормализовать.
   */
  normalizeRouteNumber(route: string): string {
    return String(route ?? '')
      .replace(/^\s*⚡\s*/i, '')
      .replace(/\s+/g, '')
      .replace(/-/g, '')
      .toUpperCase();
  },

  /**
   * В `/live` приходит много записей одного номера (реалтайм + расписание).
   * Оставляем по одной на маршрут: приоритет realtime, затем минимальное время.
   */
  pickUniqueRoutes(
    items: Array<BridgeArrival & { seconds: number }>,
  ): Array<BridgeArrival & { seconds: number }> {
    const byRoute = new Map<string, Array<BridgeArrival & { seconds: number }>>();

    for (const item of items) {
      const key = this.normalizeRouteNumber(item.route ?? '');
      if (!key) continue;
      if (!byRoute.has(key)) byRoute.set(key, []);
      byRoute.get(key)!.push(item);
    }

    const picked: Array<BridgeArrival & { seconds: number }> = [];

    byRoute.forEach(group => {
      // Сначала realtime, внутри группы — по времени
      group.sort((a, b) => {
        const aRt = a.raw_type === 'realtime' ? 0 : 1;
        const bRt = b.raw_type === 'realtime' ? 0 : 1;
        if (aRt !== bRt) return aRt - bRt;
        return a.seconds - b.seconds;
      });
      if (group[0]) picked.push(group[0]);
    });

    picked.sort((a, b) => a.seconds - b.seconds);
    return picked;
  },

  liveBoardToArrivals(
    items: BridgeArrival[],
    stop: Stop,
    logicalStopId: string,
    defaultVehicleType: TransportType,
  ): Arrival[] {
    return items.map((it, idx) => {
      const route = String(it.route ?? '').trim() || '—';
      const seconds = this.normalizeEtaSeconds(it.seconds ?? it.eta ?? 0);
      const vType = it.transport_type
        ? mapTransportType(it.transport_type)
        : defaultVehicleType;

      return {
        id: `${logicalStopId}_${this.normalizeRouteNumber(route)}_${idx}`,
        stopId: logicalStopId,
        secondsUntilArrival: seconds,
        minutesUntilArrival: Math.max(0, Math.floor(seconds / 60)),
        rawType: it.raw_type === 'realtime' ? 'realtime' : 'schedule',
        vehicle: {
          id: it.vehicle_id || `${route}_${seconds}`,
          routeId: route,
          routeNumber: route,
          type: vType,
          latitude: stop.latitude,
          longitude: stop.longitude,
          bearing: 0,
          arrivalMinutes: Math.max(0, Math.floor(seconds / 60)),
          occupancy: 'normal',
        },
      };
    });
  },

  async fetchNearestStopIds(lat: number, lon: number, limit = 4): Promise<string[]> {
    const c = await this.fetchNearestStopCluster(lat, lon, limit);
    return c?.stopIds ?? [];
  },

  /** Возвращает платформенные id + точные координаты для /live (stop_lat/stop_lon). */
  async fetchNearestStopCluster(
    lat: number,
    lon: number,
    limit = 8,
  ): Promise<{ stopIds: string[]; lat: number; lon: number } | null> {
    const data = await fetchNearestStopIdsAuto(lat, lon, limit);
    const first = data.items?.[0] as
      | {
          stop_ids?: string[];
          stop_id?: string | null;
          lat?: number;
          lon?: number;
        }
      | undefined;

    if (!first) return null;

    const stopIds = first.stop_ids?.length
      ? first.stop_ids.map(String)
      : first.stop_id
        ? [String(first.stop_id)]
        : [];

    if (stopIds.length === 0) return null;

    const platLat =
      typeof first.lat === 'number' && Number.isFinite(first.lat) ? first.lat : lat;
    const platLon =
      typeof first.lon === 'number' && Number.isFinite(first.lon) ? first.lon : lon;

    return { stopIds, lat: platLat, lon: platLon };
  },

  /**
   * Основная функция получения ETA для остановки.
   * Алгоритм:
   *   1. Резолвим stop_ids если их нет
   *   2. Запрашиваем /live
   *   3. Нормализуем секунды, фильтруем невалидные
   *   4. Дедупликация по маршруту (realtime > расписание)
   *   5. Конвертируем в Arrival[]
   */
  async fetchLiveArrivals(
    stop: Stop,
    apiLimit = 200,
    opts?: { signal?: AbortSignal },
  ): Promise<Arrival[]> {
    const resolved = await this.resolveStopForEta(stop);
    const ids = resolved.stopIds ?? [];
    if (ids.length === 0) return [];

    const defaultVehicleType = mapStopKind(resolved.type ?? stop.type);
    let buses: BridgeArrival[] = [];

    try {
      const data = await fetchLiveBoardAuto(
        ids,
        resolved.latitude,
        resolved.longitude,
        apiLimit,
        opts,
      );
      buses = data.buses ?? [];
    } catch (e: unknown) {
      const err = e as { name?: string };
      if (err?.name === 'AbortError') throw e;
      return [];
    }

    const sorted = buses
      .map(item => ({
        ...item,
        seconds: this.normalizeEtaSeconds(item.seconds ?? item.eta ?? 0),
      }))
      .filter(item => this.isReasonableEta(item.seconds))
      .sort((a, b) => a.seconds - b.seconds);

    const uniqueRoutes = this.pickUniqueRoutes(sorted);
    return this.liveBoardToArrivals(uniqueRoutes, resolved, stop.id, defaultVehicleType);
  },

  // ─── Заглушки (для совместимости с экранами) ───────────────────────────────

  fetchStops(_region: CityRegion): Stop[] {
    return [];
  },

  fetchFavoriteStops(): Stop[] {
    return [];
  },

  fetchRoutes(): Route[] {
    return [];
  },

  fetchSavedRoutes(): SavedRoute[] {
    return [];
  },

  fetchArrivals(_stopId: string): Arrival[] {
    return [];
  },

  fetchVehicles(): Vehicle[] {
    return [];
  },

  fetchTripHistory(): Trip[] {
    return [];
  },

  searchStops(query: string, stops: Stop[]): Stop[] {
    if (!query) return stops;
    const q = query.toLowerCase();
    return stops.filter(
      s =>
        s.name.toLowerCase().includes(q) ||
        s.address.toLowerCase().includes(q),
    );
  },

  getOccupancyLabel(o: OccupancyLevel): string {
    return {
      empty: 'Свободно',
      normal: 'Нормально',
      crowded: 'Многолюдно',
      full: 'Переполнен',
    }[o];
  },

  getOccupancyColor(o: OccupancyLevel): string {
    return {
      empty: '#34C759',
      normal: '#FF6B1A',
      crowded: '#FF9500',
      full: '#FF3B30',
    }[o];
  },
};
