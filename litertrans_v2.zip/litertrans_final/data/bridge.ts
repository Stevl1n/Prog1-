/**
 * Клиент моста: 1-в-1 API как в `testitdbot/mobile-ios/src/bridge.ts`
 * (функции с параметром `base`) + общий запрос с перебором URL и закреплением рабочего хоста.
 */
import Constants from 'expo-constants';

const extra = Constants.expoConfig?.extra as { bridgeBaseUrl?: string } | undefined;

/** Как в testitdbot: `app.json` extra → `EXPO_PUBLIC_BRIDGE_URL` → localhost (не наоборот). */
export const getBridgeBaseUrl = (): string => {
  const fromExtra = extra?.bridgeBaseUrl?.trim();
  if (fromExtra) return fromExtra.replace(/\/$/, '');
  const fromEnv = process.env.EXPO_PUBLIC_BRIDGE_URL?.trim();
  if (fromEnv) return fromEnv.replace(/\/$/, '');
  return 'http://127.0.0.1:18181';
};

function dedupe(urls: string[]): string[] {
  const out: string[] = [];
  for (const u of urls) {
    const n = u.trim().replace(/\/$/, '');
    if (n && !out.includes(n)) out.push(n);
  }
  return out;
}

/** Основной URL и запасные (Expo Go: dev-host, эмулятор Android). */
export const getBridgeCandidateBases = (): string[] => {
  const list: string[] = [getBridgeBaseUrl()];
  const hostUri = Constants.expoConfig?.hostUri || '';
  if (hostUri) {
    const host = hostUri.split(':')[0];
    if (host && host !== 'localhost' && host !== '127.0.0.1') {
      list.push(`http://${host}:18181`);
    }
  }
  list.push('http://10.0.2.2:18181', 'http://127.0.0.1:18181', 'http://localhost:18181');
  return dedupe(list);
};

let workingBase: string | null = null;

export const resetBridgeRouting = (): void => {
  workingBase = null;
};

function timeoutMsForPath(pathWithQuery: string): number {
  if (pathWithQuery.startsWith('/vehicles')) return 22000;
  if (pathWithQuery.startsWith('/live')) return 32000;
  if (
    pathWithQuery.startsWith('/nearest-stop-ids') ||
    pathWithQuery.startsWith('/stops')
  ) {
    return 14000;
  }
  return 6500;
}

async function bridgeRequest(
  pathWithQuery: string,
  opts?: { signal?: AbortSignal },
): Promise<Response> {
  const bases = workingBase
    ? [workingBase, ...getBridgeCandidateBases().filter(b => b !== workingBase)]
    : getBridgeCandidateBases();
  const ms = timeoutMsForPath(pathWithQuery);
  const userSignal = opts?.signal;
  let last: unknown = null;

  for (const base of bases) {
    const controller = new AbortController();
    const tid = setTimeout(() => controller.abort(), ms);
    const onUserAbort = () => controller.abort();

    if (userSignal) {
      if (userSignal.aborted) {
        clearTimeout(tid);
        const err = new Error('aborted');
        err.name = 'AbortError';
        throw err;
      }
      userSignal.addEventListener('abort', onUserAbort);
    }

    try {
      const res = await fetch(`${base}${pathWithQuery}`, {
        method: 'GET',
        signal: controller.signal,
      });

      if (!res.ok) {
        last = new Error(`${pathWithQuery}_http_${res.status}`);
        continue;
      }

      workingBase = base;
      return res;
    } catch (e) {
      const err = e as { name?: string };
      // Если пользователь отменил — пробрасываем наверх немедленно
      if (err?.name === 'AbortError' && userSignal?.aborted) {
        clearTimeout(tid);
        if (userSignal) userSignal.removeEventListener('abort', onUserAbort);
        throw e;
      }
      last = e;
    } finally {
      clearTimeout(tid);
      if (userSignal) userSignal.removeEventListener('abort', onUserAbort);
    }
  }

  throw last instanceof Error ? last : new Error('bridge_unreachable');
}

export async function bridgeFetchJson<T>(
  pathWithQuery: string,
  opts?: { signal?: AbortSignal },
): Promise<T> {
  const r = await bridgeRequest(pathWithQuery, opts);
  return (await r.json()) as T;
}

// ─── Типы и функции как в testitdbot (с явным `base`) ───────────────────────

export type BridgeVehicle = {
  vehicle_id: string;
  route: string;
  route_number: string;
  transport_type: string;
  lat: number;
  lon: number;
  speed_kmh?: number;
  bearing?: number;
  timestamp?: string;
};

export type BridgeArrival = {
  route: string;
  seconds: number;
  eta?: number;
  raw_type?: string;
  vehicle_id?: string;
  transport_type?: string;
};

export type SearchStopItem = {
  title: string;
  subtitle?: string;
  lat: number;
  lon: number;
  stop_id?: string | null;
  stop_ids?: string[];
  canonical_id?: string;
  routes?: string[];
  stop_kind?: string;
  source?: string;
};

export type BridgeStop = SearchStopItem;

export type BridgeHealth = {
  ok?: boolean;
  initialized?: boolean;
  last_init_error?: string | null;
};

export async function fetchBridgeHealth(base: string): Promise<BridgeHealth> {
  try {
    const r = await fetch(`${base}/health`, { method: 'GET' });
    if (!r.ok) return { ok: false };
    return (await r.json()) as BridgeHealth;
  } catch {
    return { ok: false };
  }
}

export async function fetchVehiclesInBbox(
  base: string,
  bbox: { south: number; west: number; north: number; east: number },
  limit = 1500,
): Promise<{ vehicles: BridgeVehicle[]; capped?: boolean }> {
  const q = new URLSearchParams({
    bbox: `${bbox.south},${bbox.west},${bbox.north},${bbox.east}`,
    limit: String(limit),
  });
  const r = await fetch(`${base}/vehicles?${q}`);
  if (!r.ok) throw new Error(`vehicles_http_${r.status}`);
  return (await r.json()) as { vehicles: BridgeVehicle[]; capped?: boolean };
}

export async function fetchLiveBoard(
  base: string,
  stopIds: string[],
  stopLat: number,
  stopLon: number,
  limit = 20,
): Promise<{ buses: BridgeArrival[]; fetched_at?: number }> {
  const q = new URLSearchParams({
    stop_ids: stopIds.join(','),
    stop_lat: String(stopLat),
    stop_lon: String(stopLon),
    limit: String(limit),
  });
  const r = await fetch(`${base}/live?${q}`);
  if (!r.ok) throw new Error(`live_http_${r.status}`);
  return (await r.json()) as { buses: BridgeArrival[]; fetched_at?: number };
}

export async function searchStops(
  base: string,
  query: string,
  limit = 12,
): Promise<SearchStopItem[]> {
  const q = new URLSearchParams({ q: query.trim(), limit: String(limit) });
  const r = await fetch(`${base}/search-stops?${q}`);
  if (!r.ok) throw new Error(`search_http_${r.status}`);
  const data = (await r.json()) as { items?: SearchStopItem[] };
  return data.items ?? [];
}

export async function fetchStopsInBbox(
  base: string,
  bbox: { south: number; west: number; north: number; east: number },
  limit = 1200,
): Promise<{ items: BridgeStop[]; count?: number; capped?: boolean }> {
  const q = new URLSearchParams({
    bbox: `${bbox.south},${bbox.west},${bbox.north},${bbox.east}`,
    limit: String(limit),
  });
  const r = await fetch(`${base}/stops?${q}`);
  if (!r.ok) throw new Error(`stops_http_${r.status}`);
  return (await r.json()) as { items: BridgeStop[]; count?: number; capped?: boolean };
}

/** Расширение ответа /nearest-stop-ids — включаем lat/lon платформы для /live. */
export async function fetchNearestStopIds(
  base: string,
  lat: number,
  lon: number,
  limit = 4,
): Promise<{ items?: Array<{ stop_ids?: string[]; stop_id?: string | null; lat?: number; lon?: number }> }> {
  const q = new URLSearchParams({
    lat: String(lat),
    lon: String(lon),
    limit: String(limit),
  });
  const r = await fetch(`${base}/nearest-stop-ids?${q}`);
  if (!r.ok) throw new Error(`nearest_http_${r.status}`);
  return (await r.json()) as {
    items?: Array<{ stop_ids?: string[]; stop_id?: string | null; lat?: number; lon?: number }>;
  };
}

// ─── Авто-выборы (использует TransportService / экраны) ─────────────────────

export async function fetchBridgeHealthAuto(): Promise<BridgeHealth> {
  return bridgeFetchJson<BridgeHealth>('/health');
}

export async function fetchStopsInBboxAuto(
  bbox: { south: number; west: number; north: number; east: number },
  limit = 1200,
): Promise<{ items?: BridgeStop[]; count?: number; capped?: boolean }> {
  const q = new URLSearchParams({
    bbox: `${bbox.south},${bbox.west},${bbox.north},${bbox.east}`,
    limit: String(limit),
  });
  return bridgeFetchJson(`/stops?${q}`);
}

export async function fetchVehiclesInBboxAuto(
  bbox: { south: number; west: number; north: number; east: number },
  limit = 1500,
): Promise<{ vehicles?: BridgeVehicle[]; capped?: boolean }> {
  const q = new URLSearchParams({
    bbox: `${bbox.south},${bbox.west},${bbox.north},${bbox.east}`,
    limit: String(limit),
  });
  return bridgeFetchJson(`/vehicles?${q}`);
}

export async function searchStopsAuto(
  query: string,
  limit = 16,
): Promise<{ items?: SearchStopItem[] }> {
  const qText = query.trim();
  if (qText.length < 2) return { items: [] };
  const q = new URLSearchParams({ q: qText, limit: String(limit) });
  return bridgeFetchJson(`/search-stops?${q}`);
}

export async function fetchLiveBoardAuto(
  stopIds: string[],
  stopLat: number,
  stopLon: number,
  limit: number,
  opts?: { signal?: AbortSignal },
): Promise<{ buses?: BridgeArrival[]; fetched_at?: number }> {
  const q = new URLSearchParams({
    stop_ids: stopIds.join(','),
    stop_lat: String(stopLat),
    stop_lon: String(stopLon),
    limit: String(limit),
  });
  return bridgeFetchJson(`/live?${q}`, opts);
}

export async function fetchNearestStopIdsAuto(
  lat: number,
  lon: number,
  limit = 4,
): Promise<{ items?: Array<{ stop_ids?: string[]; stop_id?: string | null; lat?: number; lon?: number }> }> {
  const q = new URLSearchParams({
    lat: String(lat),
    lon: String(lon),
    limit: String(limit),
  });
  return bridgeFetchJson(`/nearest-stop-ids?${q}`);
}
