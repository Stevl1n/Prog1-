/* eslint-disable @typescript-eslint/no-require-imports */
const path = require('path');

// Загружаем .env если есть
try {
  require('dotenv').config({ path: path.join(__dirname, '.env') });
} catch {
  // dotenv не установлен — не критично
}

const appJson = require('./app.json');
const fromEnv = process.env.EXPO_PUBLIC_BRIDGE_URL?.trim();

module.exports = {
  expo: {
    ...appJson.expo,
    extra: {
      ...appJson.expo.extra,
      ...(fromEnv ? { bridgeBaseUrl: fromEnv.replace(/\/$/, '') } : {}),
    },
  },
};
