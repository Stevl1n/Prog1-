import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Switch,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors } from '../constants/Colors';
import { TransportService } from '../data/TransportService';
import { useAppSettings } from '../components/AppSettingsContext';

const MENU_ITEMS = [
  { icon: 'history',              label: 'История поездок',   color: Colors.orange },
  { icon: 'cog',                  label: 'Настройки',          color: Colors.orange },
  { icon: 'credit-card',          label: 'Оплата',             color: Colors.orange },
  { icon: 'help-circle',          label: 'Поддержка',          color: Colors.orange },
  { icon: 'information-outline',  label: 'О приложении',       color: Colors.purple },
];

export default function ProfileScreen() {
  const { settings, setShowAllStopsOnMap } = useAppSettings();
  const [showHistory, setShowHistory] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const menuOpacity = useRef(new Animated.Value(0)).current;
  const trips = TransportService.fetchTripHistory();

  // Плавное появление меню при загрузке
  useEffect(() => {
    Animated.timing(menuOpacity, {
      toValue: showHistory || showSettings ? 0 : 1,
      duration: 240,
      useNativeDriver: true,
    }).start();
  }, [menuOpacity, showHistory, showSettings]);

  // ─── Экран истории поездок ────────────────────────────────────────────────

  if (showHistory) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.navRow}>
          <Pressable
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}
            onPress={() => setShowHistory(false)}
          >
            <MaterialCommunityIcons name="chevron-left" size={22} color="#fff" />
            <Text style={styles.backText}>Назад</Text>
          </Pressable>
          <Text style={styles.navTitle}>История поездок</Text>
          <View style={{ width: 80 }} />
        </View>

        <ScrollView>
          {trips.length === 0 ? (
            <View style={styles.emptyHistory}>
              <MaterialCommunityIcons
                name="bus-clock"
                size={40}
                color={Colors.textSecondary}
              />
              <Text style={styles.emptyHistoryText}>
                История поездок пуста
              </Text>
              <Text style={styles.emptyHistoryHint}>
                Здесь появятся маршруты, которые вы совершили
              </Text>
            </View>
          ) : (
            trips.map(trip => (
              <View key={trip.id} style={styles.tripRow}>
                <View style={styles.tripIconWrap}>
                  <MaterialCommunityIcons name="bus" size={20} color="#fff" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.tripRoute}>
                    Маршрут ⚡{trip.routeNumber}
                  </Text>
                  <Text style={styles.tripStops}>
                    {trip.fromStop} → {trip.toStop}
                  </Text>
                  <Text style={styles.tripMeta}>
                    {trip.date} · {trip.duration} мин
                  </Text>
                </View>
              </View>
            ))
          )}
          <View style={{ height: 100 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ─── Экран настроек ───────────────────────────────────────────────────────

  if (showSettings) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <View style={styles.navRow}>
          <Pressable
            style={({ pressed }) => [styles.backBtn, pressed && { opacity: 0.7 }]}
            onPress={() => setShowSettings(false)}
          >
            <MaterialCommunityIcons name="chevron-left" size={22} color="#fff" />
            <Text style={styles.backText}>Назад</Text>
          </Pressable>
          <Text style={styles.navTitle}>Настройки</Text>
          <View style={{ width: 80 }} />
        </View>

        <ScrollView>
          {/* Переключатель показа остановок */}
          <View style={styles.settingsCard}>
            <View style={{ flex: 1 }}>
              <Text style={styles.settingsTitle}>
                Сразу показывать все остановки
              </Text>
              <Text style={styles.settingsHint}>
                Если выключено, карта не загружает остановки до поиска.
              </Text>
            </View>
            <Switch
              value={settings.showAllStopsOnMap}
              onValueChange={setShowAllStopsOnMap}
              trackColor={{ false: Colors.separator, true: Colors.orange }}
              thumbColor="#fff"
            />
          </View>

          {/* Информация о сервере */}
          <View style={styles.serverCard}>
            <MaterialCommunityIcons
              name="server-network"
              size={18}
              color={Colors.orange}
            />
            <View style={{ flex: 1 }}>
              <Text style={styles.settingsTitle}>Адрес сервера</Text>
              <Text style={styles.serverUrl}>
                {TransportService.getBridgeBaseUrl()}
              </Text>
            </View>
          </View>

          <View style={{ height: 100 }} />
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ─── Главный экран профиля ────────────────────────────────────────────────

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        style={{ opacity: menuOpacity }}
      >
        {/* Шапка */}
        <View style={styles.header}>
          <MaterialCommunityIcons name="menu" size={22} color="#fff" />
          <Text style={styles.navTitle}>Профиль</Text>
          <View style={styles.bellBtn}>
            <MaterialCommunityIcons
              name="magnify"
              size={20}
              color={Colors.textSecondary}
            />
          </View>
        </View>

        {/* Аватар */}
        <View style={styles.avatarSection}>
          <View style={styles.avatar}>
            <MaterialCommunityIcons
              name="account"
              size={48}
              color="rgba(255,255,255,0.85)"
            />
          </View>
          <Text style={styles.userName}>Алексей</Text>
          <Text style={styles.userSub}>Пассажир</Text>
        </View>

        {/* Статистика */}
        <View style={styles.statsRow}>
          <StatItem value={String(trips.length || 0)} label="Поездок" />
          <View style={styles.statDivider} />
          <StatItem value="—" label="Маршрутов" />
          <View style={styles.statDivider} />
          <StatItem value="—" label="Избранных" />
        </View>

        {/* Меню */}
        <View style={styles.menu}>
          {MENU_ITEMS.map((item, idx) => (
            <Pressable
              key={idx}
              style={({ pressed }) => [
                styles.menuRow,
                pressed && { opacity: 0.8 },
              ]}
              onPress={
                idx === 0
                  ? () => setShowHistory(true)
                  : idx === 1
                    ? () => setShowSettings(true)
                    : undefined
              }
            >
              <View
                style={[
                  styles.menuIcon,
                  { backgroundColor: item.color + '22' },
                ]}
              >
                <MaterialCommunityIcons
                  name={item.icon as any}
                  size={20}
                  color={item.color}
                />
              </View>
              <Text style={styles.menuLabel}>{item.label}</Text>
              <MaterialCommunityIcons
                name="chevron-right"
                size={18}
                color={Colors.textSecondary}
              />
            </Pressable>
          ))}
        </View>

        {/* Выход */}
        <Pressable
          style={({ pressed }) => [
            styles.logoutBtn,
            pressed && { opacity: 0.7 },
          ]}
        >
          <Text style={styles.logoutText}>Выйти из аккаунта</Text>
        </Pressable>

        <View style={{ height: 100 }} />
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

function StatItem({ value, label }: { value: string; label: string }) {
  return (
    <View style={styles.statItem}>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 24,
  },
  navTitle: { fontSize: 18, fontWeight: '700', color: '#fff' },
  bellBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarSection: { alignItems: 'center', marginBottom: 20 },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: Colors.purple,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: Colors.purple,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 16,
    elevation: 8,
    marginBottom: 14,
  },
  userName: { fontSize: 26, fontWeight: '700', color: '#fff' },
  userSub: { fontSize: 14, color: Colors.textSecondary, marginTop: 2 },

  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.card,
    borderRadius: 18,
    marginHorizontal: 20,
    paddingVertical: 16,
    marginBottom: 28,
  },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: '700', color: '#fff' },
  statLabel: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  statDivider: {
    width: 0.5,
    height: 30,
    backgroundColor: Colors.separator,
  },

  menu: { paddingHorizontal: 20, gap: 8 },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 14,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  menuIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuLabel: { flex: 1, fontSize: 16, color: '#fff' },

  logoutBtn: {
    marginHorizontal: 20,
    marginTop: 24,
    height: 50,
    backgroundColor: Colors.card,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  logoutText: {
    fontSize: 15,
    fontWeight: '600',
    color: 'rgba(255,59,48,0.8)',
  },

  // История
  navRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 20,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    width: 80,
  },
  backText: { fontSize: 16, color: '#fff' },

  tripRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.card,
    borderRadius: 16,
    padding: 14,
    marginHorizontal: 20,
    marginBottom: 8,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  tripIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: Colors.orange,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tripRoute: { fontSize: 15, fontWeight: '600', color: '#fff' },
  tripStops: { fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  tripMeta: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },

  emptyHistory: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 60,
    gap: 12,
    paddingHorizontal: 40,
  },
  emptyHistoryText: {
    fontSize: 17,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  emptyHistoryHint: {
    fontSize: 13,
    color: Colors.textSecondary,
    textAlign: 'center',
    opacity: 0.7,
  },

  // Настройки
  settingsCard: {
    marginHorizontal: 20,
    marginTop: 4,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.separator,
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  serverCard: {
    marginHorizontal: 20,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.separator,
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  settingsTitle: {
    fontSize: 15,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  settingsHint: { fontSize: 12, color: Colors.textSecondary },
  serverUrl: {
    fontSize: 12,
    color: Colors.orange,
    fontFamily: 'Courier New',
    marginTop: 2,
  },
});
