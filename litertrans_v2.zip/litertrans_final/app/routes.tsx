import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  Pressable, TextInput, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors, TransportColors, TransportIcons } from '../constants/Colors';
import { TransportService, Route, SavedRoute } from '../data/TransportService';
import RouteDetailModal from '../components/RouteDetailModal';

export default function RoutesScreen() {
  const [searchText, setSearchText] = useState('');
  const [allRoutes, setAllRoutes] = useState<Route[]>([]);
  const [loading, setLoading] = useState(false);
  const [savedRoutes] = useState<SavedRoute[]>(() => TransportService.fetchSavedRoutes());
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);

  useEffect(() => {
    setLoading(true);
    // Загружаем остановки по всему СПб и строим список маршрутов
    const bbox = { south: 59.62, west: 29.85, north: 60.22, east: 30.95 };
    TransportService.fetchStopsInBbox(bbox, 10000)
      .then(stops => {
        const map = new Map<string, Route>();

        stops.forEach(stop => {
          (stop.routes || []).forEach(routeNumber => {
            const key = routeNumber.trim();
            if (!key) return;

            if (!map.has(key)) {
              const hash = Array.from(key).reduce(
                (acc, ch) => acc + ch.charCodeAt(0),
                0,
              );
              const palette = [
                Colors.orange,
                Colors.purple,
                '#FF3B30',
                '#007AFF',
                '#34C759',
              ];
              map.set(key, {
                id: `route_${key}`,
                number: key,
                name: `Маршрут ⚡${key}`,
                type: stop.type || 'bus',
                stops: [stop],
                isFavorite: false,
                color: palette[hash % palette.length],
              });
            } else {
              map.get(key)?.stops.push(stop);
            }
          });
        });

        if (map.size > 0) {
          setAllRoutes(
            Array.from(map.values()).sort((a, b) =>
              a.number.localeCompare(b.number, 'ru', { numeric: true }),
            ),
          );
        }
      })
      .catch(() => undefined)
      .finally(() => setLoading(false));
  }, []);

  const filteredRoutes = searchText
    ? allRoutes.filter(
        r =>
          r.number.toLowerCase().includes(searchText.toLowerCase()) ||
          r.name.toLowerCase().includes(searchText.toLowerCase()),
      )
    : allRoutes;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Заголовок */}
        <View style={styles.header}>
          <View>
            <Text style={styles.headerSub}>ЛитерТранс</Text>
            <Text style={styles.headerTitle}>Маршруты</Text>
          </View>
          <View style={styles.menuBtn}>
            <MaterialCommunityIcons name="menu" size={22} color="#fff" />
          </View>
        </View>

        {/* Поиск */}
        <View style={styles.searchContainer}>
          <MaterialCommunityIcons
            name="magnify"
            size={20}
            color={Colors.textSecondary}
          />
          <TextInput
            style={styles.searchInput}
            placeholder="От: Дом  ·  До: Работа"
            placeholderTextColor={Colors.textSecondary}
            value={searchText}
            onChangeText={setSearchText}
            returnKeyType="search"
            clearButtonMode="while-editing"
          />
        </View>

        {/* Избранные маршруты */}
        {savedRoutes.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Мои любимые маршруты</Text>
            {savedRoutes.map(route => (
              <SavedRouteCard key={route.id} route={route} />
            ))}
          </View>
        )}

        {/* Все маршруты */}
        <View style={styles.section}>
          <View style={styles.sectionTitleRow}>
            <Text style={styles.sectionTitle}>Все маршруты</Text>
            {loading ? (
              <ActivityIndicator color={Colors.orange} size="small" />
            ) : (
              <Text style={styles.countBadge}>{allRoutes.length}</Text>
            )}
          </View>

          {!loading && filteredRoutes.length === 0 && (
            <View style={styles.emptyWrap}>
              <MaterialCommunityIcons
                name="magnify-close"
                size={32}
                color={Colors.textSecondary}
              />
              <Text style={styles.emptyText}>
                {searchText ? 'Ничего не найдено' : 'Нет данных'}
              </Text>
            </View>
          )}

          {filteredRoutes.map(route => (
            <Pressable
              key={route.id}
              onPress={() => setSelectedRoute(route)}
              style={({ pressed }) => [pressed && { opacity: 0.85 }]}
            >
              <RouteCell route={route} />
            </Pressable>
          ))}
        </View>

        <View style={{ height: 100 }} />
      </ScrollView>

      <RouteDetailModal
        route={selectedRoute}
        onClose={() => setSelectedRoute(null)}
      />
    </SafeAreaView>
  );
}

function SavedRouteCard({ route }: { route: SavedRoute }) {
  return (
    <View style={[styles.savedCard, { backgroundColor: route.color }]}>
      <MaterialCommunityIcons name="star" size={20} color="rgba(255,255,255,0.9)" />
      <View style={{ flex: 1, marginTop: 8 }}>
        <Text style={styles.savedCardText}>
          {route.fromName} · {route.toName}
        </Text>
      </View>
    </View>
  );
}

function RouteCell({ route }: { route: Route }) {
  const iconName = (TransportIcons[route.type] as any) || 'bus';

  return (
    <View style={styles.routeCell}>
      {/* Иконка транспорта с правильным цветом */}
      <View
        style={[
          styles.routeIcon,
          { backgroundColor: TransportColors[route.type] || route.color },
        ]}
      >
        <MaterialCommunityIcons name={iconName} size={20} color="#fff" />
      </View>

      <View style={{ flex: 1 }}>
        {/* Линия маршрута (визуальная) */}
        <View style={styles.routeLine}>
          <View
            style={[
              styles.routeLinePart,
              { backgroundColor: route.color, width: 60 },
            ]}
          />
          <View
            style={[
              styles.routeLinePart,
              { backgroundColor: route.color + '80', width: 30 },
            ]}
          />
          <View
            style={[
              styles.routeLinePart,
              { backgroundColor: route.color + '33', width: 20 },
            ]}
          />
        </View>

        <Text style={styles.routeName}>{route.name}</Text>
        <Text style={styles.routeMeta}>
          {route.stops.length} {stopWord(route.stops.length)}
        </Text>
      </View>

      <View style={{ alignItems: 'flex-end', gap: 4 }}>
        <MaterialCommunityIcons
          name="chevron-right"
          size={16}
          color={Colors.textSecondary}
        />
      </View>
    </View>
  );
}

/** Склонение слова «остановка». */
function stopWord(n: number): string {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod100 >= 11 && mod100 <= 19) return 'остановок';
  if (mod10 === 1) return 'остановка';
  if (mod10 >= 2 && mod10 <= 4) return 'остановки';
  return 'остановок';
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  header: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 20,
  },
  headerSub: { fontSize: 14, color: Colors.textSecondary },
  headerTitle: { fontSize: 32, fontWeight: '700', color: '#fff' },
  menuBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },

  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.card,
    borderRadius: 14,
    paddingHorizontal: 14,
    height: 48,
    marginHorizontal: 20,
    borderWidth: 0.5,
    borderColor: Colors.separator,
    marginBottom: 24,
  },
  searchInput: { flex: 1, color: '#fff', fontSize: 15 },

  section: { paddingHorizontal: 20, marginBottom: 24 },
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  countBadge: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontWeight: '600',
  },

  savedCard: {
    borderRadius: 20,
    padding: 16,
    height: 110,
    marginBottom: 12,
    justifyContent: 'space-between',
  },
  savedCardText: { fontSize: 17, fontWeight: '600', color: '#fff' },

  routeCell: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: Colors.card,
    borderRadius: 18,
    padding: 14,
    marginBottom: 8,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  routeIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  routeLine: { flexDirection: 'row', gap: 4, marginBottom: 6 },
  routeLinePart: { height: 4, borderRadius: 2 },
  routeName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  routeMeta: { fontSize: 12, color: Colors.textSecondary },

  emptyWrap: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
    gap: 12,
  },
  emptyText: {
    color: Colors.textSecondary,
    fontSize: 15,
    fontWeight: '500',
  },
});
