import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
  Pressable,
  TextInput,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Colors, TransportColors, TransportIcons } from '../constants/Colors';
import { TransportService, Stop } from '../data/TransportService';
import StopDetailModal from '../components/StopDetailModal';

type FilterTab = 'Все' | 'Остановки' | 'Маршруты' | 'Районы';
const FILTERS: FilterTab[] = ['Все', 'Остановки', 'Маршруты', 'Районы'];

export default function SearchScreen() {
  const [searchText, setSearchText] = useState('');
  const [filter, setFilter] = useState<FilterTab>('Все');
  const [stops, setStops] = useState<Stop[]>([]);
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [loading, setLoading] = useState(false);

  const resultsOpacity = useRef(new Animated.Value(1)).current;

  // Уникальные маршруты из результатов
  const routeResults = useMemo(
    () => [...new Set(stops.flatMap(stop => stop.routes))].slice(0, 20),
    [stops],
  );

  // Уникальные районы/названия из первой части адреса
  const districtResults = useMemo(
    () =>
      stops
        .map(stop => stop.name.split(',')[0])
        .filter((name, idx, arr) => arr.indexOf(name) === idx)
        .slice(0, 15),
    [stops],
  );

  // Fade-анимация при смене фильтра/запроса
  useEffect(() => {
    resultsOpacity.setValue(0.5);
    Animated.timing(resultsOpacity, {
      toValue: 1,
      duration: 220,
      useNativeDriver: true,
    }).start();
  }, [filter, searchText, resultsOpacity]);

  // Дебаунс поиска — 320 мс после последнего ввода
  useEffect(() => {
    const query = searchText.trim();
    const timer = setTimeout(() => {
      if (query.length < 2) {
        setStops([]);
        return;
      }
      setLoading(true);
      TransportService.searchBridgeStops(query, 24)
        .then(setStops)
        .catch(() => setStops([]))
        .finally(() => setLoading(false));
    }, 320);

    return () => clearTimeout(timer);
  }, [searchText]);

  // Определяем, какие секции показывать
  const showStops = filter === 'Все' || filter === 'Остановки';
  const showRoutes = filter === 'Все' || filter === 'Маршруты';
  const showDistricts = filter === 'Все' || filter === 'Районы';

  const hasResults =
    (showStops && stops.length > 0) ||
    (showRoutes && routeResults.length > 0) ||
    (showDistricts && districtResults.length > 0);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Заголовок */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialCommunityIcons name="menu" size={20} color={Colors.orange} />
          <Text style={styles.headerTitle}>«ЛитерТранс»</Text>
        </View>
        <View style={styles.bellBtn}>
          <MaterialCommunityIcons name="bell" size={20} color={Colors.textSecondary} />
        </View>
      </View>

      {/* Поиск */}
      <View style={styles.searchBar}>
        <MaterialCommunityIcons name="magnify" size={20} color={Colors.textSecondary} />
        <TextInput
          style={styles.searchInput}
          placeholder="Поиск остановок"
          placeholderTextColor={Colors.textSecondary}
          value={searchText}
          onChangeText={setSearchText}
          returnKeyType="search"
          autoCorrect={false}
        />
        {searchText !== '' && (
          <Pressable
            onPress={() => setSearchText('')}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <MaterialCommunityIcons
              name="close-circle"
              size={18}
              color={Colors.textSecondary}
            />
          </Pressable>
        )}
      </View>

      {/* Фильтры */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.filterRow}
        contentContainerStyle={{ paddingHorizontal: 20, gap: 8 }}
      >
        {FILTERS.map(f => (
          <Pressable
            key={f}
            style={({ pressed }) => [
              styles.chip,
              filter === f && styles.chipActive,
              pressed && { opacity: 0.8 },
            ]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.chipText, filter === f && styles.chipTextActive]}>
              {f}
            </Text>
          </Pressable>
        ))}
      </ScrollView>

      {/* Результаты */}
      <Animated.View style={{ flex: 1, opacity: resultsOpacity }}>
        <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }}>

          {/* Пустое состояние */}
          {!hasResults && (
            <View style={styles.emptyState}>
              {loading ? (
                <>
                  <ActivityIndicator color={Colors.orange} />
                  <Text style={styles.emptyStateText}>Ищем остановки...</Text>
                </>
              ) : searchText.trim().length >= 2 ? (
                <>
                  <MaterialCommunityIcons
                    name="magnify-close"
                    size={32}
                    color={Colors.textSecondary}
                  />
                  <Text style={styles.emptyStateText}>Ничего не найдено</Text>
                  <Text style={styles.emptyStateHint}>
                    Попробуйте другое название
                  </Text>
                </>
              ) : (
                <>
                  <MaterialCommunityIcons
                    name="map-search-outline"
                    size={32}
                    color={Colors.textSecondary}
                  />
                  <Text style={styles.emptyStateText}>Введите название остановки</Text>
                  <Text style={styles.emptyStateHint}>Минимум 2 символа</Text>
                </>
              )}
            </View>
          )}

          {/* Остановки */}
          {showStops && stops.length > 0 && (
            <>
              <View style={styles.sectionHeader}>
                <Text style={styles.sectionTitle}>Остановки</Text>
                <Text style={styles.sectionCount}>{stops.length}</Text>
              </View>
              {stops.map((stop, idx) => (
                <Pressable
                  key={stop.id}
                  style={({ pressed }) => [
                    styles.stopRow,
                    pressed && { opacity: 0.8, transform: [{ scale: 0.99 }] },
                  ]}
                  onPress={() => setSelectedStop(stop)}
                >
                  {/* Иконка по типу транспорта */}
                  <View
                    style={[
                      styles.stopIcon,
                      {
                        backgroundColor:
                          TransportColors[stop.type || 'bus'],
                      },
                    ]}
                  >
                    <MaterialCommunityIcons
                      name={
                        (TransportIcons[stop.type || 'bus'] as any) || 'bus'
                      }
                      size={18}
                      color="#fff"
                    />
                  </View>

                  {/* Название */}
                  <Text
                    style={[
                      styles.stopName,
                      idx === 0 && styles.stopNameHighlight,
                    ]}
                    numberOfLines={1}
                  >
                    {stop.name}
                  </Text>

                  {/* Бейджи маршрутов (до 3) */}
                  <View style={styles.routeBadges}>
                    {stop.routes.slice(0, 3).map(r => (
                      <View
                        key={r}
                        style={[
                          styles.routeBadge,
                          {
                            backgroundColor:
                              TransportColors[stop.type || 'bus'],
                          },
                        ]}
                      >
                        <Text style={styles.routeBadgeText}>{r}</Text>
                      </View>
                    ))}
                    {stop.routes.length > 3 && (
                      <Text style={styles.routeBadgeMore}>
                        +{stop.routes.length - 3}
                      </Text>
                    )}
                  </View>
                </Pressable>
              ))}
            </>
          )}

          {/* Маршруты */}
          {showRoutes && routeResults.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>Маршруты</Text>
              {routeResults.map(route => (
                <View key={route} style={styles.infoRow}>
                  <MaterialCommunityIcons
                    name="bus"
                    size={16}
                    color={Colors.orange}
                  />
                  <Text style={styles.infoText}>Маршрут ⚡{route}</Text>
                </View>
              ))}
            </>
          )}

          {/* Районы */}
          {showDistricts && districtResults.length > 0 && (
            <>
              <Text style={styles.sectionTitle}>Районы</Text>
              {districtResults.map(name => (
                <View key={name} style={styles.infoRow}>
                  <MaterialCommunityIcons
                    name="map-marker-radius"
                    size={16}
                    color={Colors.purple}
                  />
                  <Text style={styles.infoText}>{name}</Text>
                </View>
              ))}
            </>
          )}

          <View style={{ height: 100 }} />
        </ScrollView>
      </Animated.View>

      <StopDetailModal
        stop={selectedStop}
        onClose={() => setSelectedStop(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  headerTitle: { fontSize: 18, fontWeight: '700', color: '#fff' },
  bellBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'center',
  },

  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: Colors.card,
    borderRadius: 14,
    paddingHorizontal: 16,
    height: 48,
    marginHorizontal: 20,
    marginBottom: 12,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  searchInput: { flex: 1, color: '#fff', fontSize: 16 },

  filterRow: { marginBottom: 12 },
  chip: {
    backgroundColor: Colors.card,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  chipActive: { backgroundColor: Colors.orange },
  chipText: { fontSize: 14, fontWeight: '600', color: Colors.textSecondary },
  chipTextActive: { color: '#fff' },

  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 10,
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
    paddingHorizontal: 20,
    paddingBottom: 10,
    marginTop: 4,
  },
  sectionCount: {
    fontSize: 13,
    color: Colors.textSecondary,
    fontWeight: '600',
  },

  stopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    backgroundColor: Colors.card,
    borderRadius: 14,
    padding: 12,
    marginHorizontal: 20,
    marginBottom: 8,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  stopIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  stopName: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    color: '#fff',
  },
  stopNameHighlight: { color: Colors.orange },
  routeBadges: { flexDirection: 'row', gap: 4, flexShrink: 0 },
  routeBadge: {
    borderRadius: 10,
    paddingHorizontal: 7,
    paddingVertical: 3,
  },
  routeBadgeText: { fontSize: 11, fontWeight: '700', color: '#fff' },
  routeBadgeMore: {
    fontSize: 11,
    fontWeight: '600',
    color: Colors.textSecondary,
    alignSelf: 'center',
  },

  infoRow: {
    marginHorizontal: 20,
    marginBottom: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: Colors.card,
    borderWidth: 0.5,
    borderColor: Colors.separator,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: { color: '#fff', fontSize: 14, fontWeight: '500' },

  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 60,
    gap: 10,
  },
  emptyStateText: {
    fontSize: 16,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  emptyStateHint: {
    fontSize: 13,
    color: Colors.textSecondary,
    opacity: 0.7,
  },
});
