import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Animated,
  LayoutAnimation,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  UIManager,
  View,
} from 'react-native';
import MapView, { Marker, PROVIDER_DEFAULT, Region } from 'react-native-maps';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, TransportColors, TransportIcons, TransportShortLabels } from '../constants/Colors';
import { DEFAULT_STOP } from '../data/defaultStop';
import { Arrival, Stop, TransportService, Vehicle } from '../data/TransportService';
import { useAppSettings } from '../components/AppSettingsContext';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

/** Стартовая область карты — берётся из defaultStop.ts. */
const SPB_REGION: Region = {
  latitude: DEFAULT_STOP.lat,
  longitude: DEFAULT_STOP.lon,
  latitudeDelta: 0.12,
  longitudeDelta: 0.12,
};

/** Расширяем bbox на `pad` коэффициент для подгрузки за краями экрана. */
function regionToBbox(region: Region, pad = 1.04) {
  const dLat = (region.latitudeDelta / 2) * pad;
  const dLon = (region.longitudeDelta / 2) * pad;
  return {
    south: region.latitude - dLat,
    west: region.longitude - dLon,
    north: region.latitude + dLat,
    east: region.longitude + dLon,
  };
}

/** Максимальное количество отображаемых маркеров остановок в зависимости от масштаба. */
function getMaxStopsByZoom(region: Region) {
  if (region.latitudeDelta < 0.02) return 1400;
  if (region.latitudeDelta < 0.06) return 900;
  if (region.latitudeDelta < 0.12) return 600;
  return 400;
}

/**
 * Прореживаем остановки, если их слишком много для рендера.
 * При активном поиске лимит снимаем (отображаем все найденные).
 */
function decimateStops(stops: Stop[], region: Region, searchActive: boolean): Stop[] {
  if (searchActive) return stops.slice(0, 2500);
  const max = getMaxStopsByZoom(region);
  if (stops.length <= max) return stops;
  const step = Math.ceil(stops.length / max);
  const result: Stop[] = [];
  for (let i = 0; i < stops.length; i += step) {
    result.push(stops[i]);
  }
  return result;
}

/** Форматируем ETA в читаемую строку. */
function formatEta(arrival: Arrival) {
  const seconds = Math.max(0, arrival.secondsUntilArrival ?? arrival.minutesUntilArrival * 60);
  if (seconds < 60) return `${seconds} с`;
  if (seconds >= 60 * 60) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${h} ч ${m.toString().padStart(2, '0')} мин`;
  }
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m} мин ${s.toString().padStart(2, '0')} с`;
}

// ─── Маркер остановки ─────────────────────────────────────────────────────────

type StopMarkerProps = {
  stop: Stop;
  selected: boolean;
  onPress: (s: Stop) => void;
  opacity: Animated.Value;
};

const StopMapMarker = React.memo(function StopMapMarker({
  stop,
  selected,
  onPress,
  opacity,
}: StopMarkerProps) {
  return (
    <Marker
      coordinate={{ latitude: stop.latitude, longitude: stop.longitude }}
      onPress={() => onPress(stop)}
      tracksViewChanges={false}
    >
      <Animated.View style={{ alignItems: 'center', justifyContent: 'center', opacity }}>
        <View
          style={[
            styles.stopMarker,
            selected && styles.stopMarkerSelected,
            { backgroundColor: TransportColors[stop.type || 'bus'] },
          ]}
        >
          <MaterialCommunityIcons
            name={(TransportIcons[stop.type || 'bus'] as any) || 'bus'}
            size={11}
            color="#fff"
          />
        </View>
      </Animated.View>
    </Marker>
  );
});

// ─── Маркер транспортного средства ───────────────────────────────────────────

type VehicleMarkerProps = {
  vehicle: Vehicle;
  highlighted: boolean;
  onPress: (v: Vehicle) => void;
};

const VehicleMapMarker = React.memo(function VehicleMapMarker({
  vehicle,
  highlighted,
  onPress,
}: VehicleMarkerProps) {
  return (
    <Marker
      coordinate={{ latitude: vehicle.latitude, longitude: vehicle.longitude }}
      title={`Маршрут ${vehicle.routeNumber}`}
      tracksViewChanges={false}
      onPress={() => onPress(vehicle)}
    >
      <View style={styles.vehicleMarkerWrap}>
        {highlighted ? <View style={styles.vehicleRouteHalo} /> : null}
        <View
          style={[
            styles.vehicleMarker,
            highlighted && styles.vehicleMarkerRouteHighlight,
            { backgroundColor: TransportColors[vehicle.type] },
          ]}
        >
          <MaterialCommunityIcons
            name={(TransportIcons[vehicle.type] as any) || 'bus'}
            size={12}
            color="#fff"
          />
        </View>
      </View>
    </Marker>
  );
});

// ─── Главный экран ────────────────────────────────────────────────────────────

export default function MapScreen() {
  const { settings } = useAppSettings();

  const [viewportRegion, setViewportRegion] = useState<Region>(SPB_REGION);
  const [stops, setStops] = useState<Stop[]>([]);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [showSearch, setShowSearch] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [arrivals, setArrivals] = useState<Arrival[]>([]);
  const [boardLoading, setBoardLoading] = useState(false);
  const [sheetVisible, setSheetVisible] = useState(false);
  const [loadingStops, setLoadingStops] = useState(false);
  const [loadingVehicles, setLoadingVehicles] = useState(false);

  // Animated values
  const stopMarkerOpacity = useRef(new Animated.Value(1)).current;
  const topBarShift = useRef(new Animated.Value(0)).current;
  const searchReveal = useRef(new Animated.Value(0)).current;
  const sheetSlide = useRef(new Animated.Value(0)).current;
  const handlePulse = useRef(new Animated.Value(0)).current;
  const handleLoopRef = useRef<{ stop: () => void } | null>(null);

  const [highlightedRouteKey, setHighlightedRouteKey] = useState<string | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const regionRef = useRef<Region>(SPB_REGION);

  // Анимированное обновление списка прибытий
  const setArrivalsAnimated = useCallback((next: Arrival[]) => {
    LayoutAnimation.configureNext(
      LayoutAnimation.create(
        340,
        LayoutAnimation.Types.easeInEaseOut,
        LayoutAnimation.Properties.opacity,
      ),
    );
    setArrivals(next);
  }, []);

  // Нажатие на маркер остановки
  const onStopPressCb = useCallback((stop: Stop) => {
    setArrivals([]);
    setSelectedStop(stop);
    setSheetVisible(true);
  }, []);

  // Обновление только транспортных средств
  const refreshVehiclesOnly = useCallback(async (nextRegion: Region) => {
    const bbox = regionToBbox(nextRegion, 1.12);
    setLoadingVehicles(true);
    try {
      const v = await TransportService.fetchVehiclesInBbox(bbox, 1200);
      setVehicles(v);
    } catch {
      setVehicles([]);
    } finally {
      setLoadingVehicles(false);
    }
  }, []);

  // Обновление только остановок
  const refreshStopsOnly = useCallback(
    async (nextRegion: Region) => {
      if (!settings.showAllStopsOnMap && searchText.trim() === '') {
        setStops([]);
        setLoadingStops(false);
        return;
      }
      const bbox = regionToBbox(nextRegion, 1.0);
      setLoadingStops(true);
      try {
        const s = await TransportService.fetchStopsInBbox(bbox, 900);
        setStops(s);
      } catch {
        setStops([]);
      } finally {
        setLoadingStops(false);
      }
    },
    [settings.showAllStopsOnMap, searchText],
  );

  // Полное обновление карты
  const refreshMapData = useCallback(
    async (nextRegion: Region) => {
      await Promise.all([
        refreshVehiclesOnly(nextRegion),
        refreshStopsOnly(nextRegion),
      ]);
    },
    [refreshVehiclesOnly, refreshStopsOnly],
  );

  // Первоначальная загрузка + автообновление каждые 5 с
  useEffect(() => {
    void refreshVehiclesOnly(regionRef.current);
    void refreshStopsOnly(regionRef.current);

    const vehTimer = setInterval(() => {
      void refreshVehiclesOnly(regionRef.current);
    }, 5000);

    const stopsTimer = setInterval(() => {
      void refreshStopsOnly(regionRef.current);
    }, 5000);

    return () => {
      clearInterval(vehTimer);
      clearInterval(stopsTimer);
    };
  }, [refreshVehiclesOnly, refreshStopsOnly]);

  // Перезагружаем остановки при смене настроек / поиска
  useEffect(() => {
    void refreshStopsOnly(regionRef.current);
  }, [settings.showAllStopsOnMap, searchText, refreshStopsOnly]);

  // ─── Видимые и отрисованные остановки ────────────────────────────────────

  const visibleStops = useMemo(
    () =>
      settings.showAllStopsOnMap || searchText.trim() !== ''
        ? searchText.trim()
          ? stops.filter(s =>
              s.name.toLowerCase().includes(searchText.trim().toLowerCase()),
            )
          : stops
        : [],
    [settings.showAllStopsOnMap, searchText, stops],
  );

  const renderedStops = useMemo(
    () => decimateStops(visibleStops, viewportRegion, searchText.trim().length > 0),
    [visibleStops, viewportRegion, searchText],
  );

  // Fade-in/out маркеров остановок
  useEffect(() => {
    Animated.timing(stopMarkerOpacity, {
      toValue: visibleStops.length > 0 ? 1 : 0,
      duration: 260,
      useNativeDriver: true,
    }).start();
  }, [visibleStops.length, stopMarkerOpacity]);

  // Анимация строки поиска
  useEffect(() => {
    Animated.parallel([
      Animated.spring(topBarShift, {
        toValue: showSearch ? 6 : 0,
        friction: 9,
        tension: 80,
        useNativeDriver: true,
      }),
      Animated.spring(searchReveal, {
        toValue: showSearch ? 1 : 0,
        friction: 10,
        tension: 90,
        useNativeDriver: true,
      }),
    ]).start();
  }, [showSearch, topBarShift, searchReveal]);

  // Анимация нижнего листа
  useEffect(() => {
    Animated.spring(sheetSlide, {
      toValue: sheetVisible ? 1 : 0,
      friction: 9,
      tension: 68,
      useNativeDriver: true,
    }).start();
  }, [sheetVisible, sheetSlide]);

  // Пульс ручки листа
  useEffect(() => {
    if (!sheetVisible) {
      handleLoopRef.current?.stop?.();
      handlePulse.setValue(0);
      return;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(handlePulse, {
          toValue: 1,
          duration: 1100,
          useNativeDriver: true,
        }),
        Animated.timing(handlePulse, {
          toValue: 0,
          duration: 1100,
          useNativeDriver: true,
        }),
      ]),
    );
    handleLoopRef.current = loop;
    loop.start();
    return () => {
      loop.stop?.();
      handleLoopRef.current = null;
    };
  }, [sheetVisible, handlePulse]);

  // Получение прибытий для выбранной остановки
  useEffect(() => {
    if (!sheetVisible || !selectedStop) return;

    const ac = new AbortController();
    const tick = async (showSpinner: boolean) => {
      if (showSpinner) setBoardLoading(true);
      try {
        const eta = await TransportService.fetchLiveArrivals(selectedStop, 220, {
          signal: ac.signal,
        });
        if (!ac.signal.aborted) setArrivalsAnimated(eta);
      } catch (e: unknown) {
        const err = e as { name?: string };
        if (err?.name === 'AbortError' || ac.signal.aborted) return;
      } finally {
        if (showSpinner && !ac.signal.aborted) setBoardLoading(false);
      }
    };

    void tick(true);
    const id = setInterval(() => {
      void tick(false);
    }, 5000);

    return () => {
      ac.abort();
      clearInterval(id);
    };
  }, [selectedStop, sheetVisible, setArrivalsAnimated]);

  // Подсветка маршрута на карте
  const toggleRouteHighlight = useCallback((routeNumber: string) => {
    const key = TransportService.normalizeRouteNumber(routeNumber);
    if (!key) return;
    setHighlightedRouteKey(prev => (prev === key ? null : key));
  }, []);

  // Закрытие нижнего листа
  const closeSheet = useCallback(() => {
    setSheetVisible(false);
    setHighlightedRouteKey(null);
    setArrivals([]);
  }, []);

  return (
    <View style={styles.container}>
      {/* Карта */}
      <MapView
        style={StyleSheet.absoluteFillObject}
        provider={PROVIDER_DEFAULT}
        initialRegion={SPB_REGION}
        showsCompass={false}
        rotateEnabled
        pitchEnabled
        moveOnMarkerPress={false}
        onRegionChangeComplete={nextRegion => {
          regionRef.current = nextRegion;
          setViewportRegion(nextRegion);
          setLoadingStops(true);
          if (debounceRef.current) clearTimeout(debounceRef.current);
          debounceRef.current = setTimeout(() => {
            refreshMapData(nextRegion);
          }, 450);
        }}
        showsUserLocation
        userInterfaceStyle="dark"
      >
        {/* Остановки */}
        {renderedStops.map(stop => (
          <StopMapMarker
            key={stop.id}
            stop={stop}
            selected={selectedStop?.id === stop.id}
            onPress={onStopPressCb}
            opacity={stopMarkerOpacity}
          />
        ))}

        {/* Транспортные средства */}
        {vehicles.map((vehicle, vIdx) => (
          <VehicleMapMarker
            key={`${vehicle.id}_${vIdx}`}
            vehicle={vehicle}
            highlighted={
              highlightedRouteKey !== null &&
              TransportService.normalizeRouteNumber(vehicle.routeNumber) ===
                highlightedRouteKey
            }
            onPress={v => toggleRouteHighlight(v.routeNumber)}
          />
        ))}
      </MapView>

      {/* Топ-бар */}
      <Animated.View style={{ transform: [{ translateY: topBarShift }] }}>
        <SafeAreaView edges={['top']} style={styles.topBar}>
          <View style={styles.topRow}>
            {showSearch ? (
              <>
                <Pressable
                  accessibilityLabel="Закрыть поиск"
                  onPress={() => {
                    setShowSearch(false);
                    setSearchText('');
                  }}
                  style={({ pressed }) => [
                    styles.iconBtn,
                    pressed && styles.pressablePressed,
                  ]}
                >
                  <MaterialCommunityIcons name="close" size={22} color="#fff" />
                </Pressable>

                <Animated.View
                  style={[
                    styles.searchBar,
                    {
                      flex: 1,
                      opacity: searchReveal,
                      transform: [
                        {
                          translateX: searchReveal.interpolate({
                            inputRange: [0, 1],
                            outputRange: [14, 0],
                          }),
                        },
                      ],
                    },
                  ]}
                >
                  <MaterialCommunityIcons
                    name="magnify"
                    size={18}
                    color={Colors.textSecondary}
                  />
                  <TextInput
                    style={styles.searchInput}
                    placeholder="Поиск остановок..."
                    placeholderTextColor={Colors.textSecondary}
                    value={searchText}
                    onChangeText={setSearchText}
                    autoFocus
                    returnKeyType="search"
                    clearButtonMode="while-editing"
                  />
                </Animated.View>
              </>
            ) : (
              <>
                <Pressable
                  onPress={() => setShowSearch(true)}
                  style={({ pressed }) => [
                    styles.iconBtn,
                    pressed && styles.pressablePressed,
                  ]}
                >
                  <MaterialCommunityIcons name="magnify" size={22} color="#fff" />
                </Pressable>

                <Text style={styles.appTitle}>ЛитерТранс</Text>

                <Pressable
                  onPress={() => refreshMapData(regionRef.current)}
                  style={({ pressed }) => [
                    styles.iconBtn,
                    pressed && styles.pressablePressed,
                  ]}
                >
                  <MaterialCommunityIcons
                    name="refresh"
                    size={22}
                    color={Colors.orange}
                  />
                </Pressable>
              </>
            )}
          </View>

          {/* Строка статуса */}
          <View style={styles.metaRow}>
            <Text style={styles.metaText}>
              {loadingVehicles ? 'ТС...' : `ТС ${vehicles.length}`}
              {'  ·  '}
              {loadingStops
                ? 'Остановки...'
                : `Остановки ${renderedStops.length}/${visibleStops.length}`}
            </Text>
          </View>

          {/* Подсказка: остановки скрыты */}
          {!settings.showAllStopsOnMap && searchText.trim() === '' && (
            <View style={styles.noticeCard}>
              <MaterialCommunityIcons
                name="information-outline"
                size={14}
                color={Colors.orange}
              />
              <Text style={styles.noticeText}>
                Показ остановок отключён в настройках
              </Text>
            </View>
          )}
        </SafeAreaView>
      </Animated.View>

      {/* Нижний лист с прибытиями */}
      <Modal
        visible={sheetVisible}
        transparent
        animationType="fade"
        onRequestClose={closeSheet}
      >
        <View style={styles.modalRoot}>
          <Pressable
            style={styles.sheetOverlayPress}
            onPress={closeSheet}
            accessibilityLabel="Закрыть"
          />

          <Animated.View
            style={[
              styles.sheet,
              {
                opacity: sheetSlide.interpolate({
                  inputRange: [0, 0.35, 1],
                  outputRange: [0, 0.92, 1],
                }),
                transform: [
                  {
                    translateY: sheetSlide.interpolate({
                      inputRange: [0, 1],
                      outputRange: [56, 0],
                    }),
                  },
                  {
                    scale: sheetSlide.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.96, 1],
                    }),
                  },
                ],
              },
            ]}
          >
            {/* Ручка */}
            <Animated.View
              style={[
                styles.sheetHandle,
                {
                  opacity: handlePulse.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.45, 1],
                  }),
                  transform: [
                    {
                      scaleX: handlePulse.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0.85, 1],
                      }),
                    },
                  ],
                },
              ]}
            />

            {selectedStop && (
              <>
                {/* Заголовок остановки */}
                <View style={styles.sheetHeader}>
                  <Text style={styles.sheetSubtitle}>Остановка:</Text>
                  <Text style={styles.sheetTitle}>{selectedStop.name}</Text>
                  <View style={styles.sheetAddressRow}>
                    <MaterialCommunityIcons
                      name="map-marker"
                      size={12}
                      color={Colors.purple}
                    />
                    <Text style={styles.sheetAddress}>{selectedStop.address}</Text>
                  </View>
                  {/* Маршруты остановки */}
                  {selectedStop.routes.length > 0 && (
                    <Text style={styles.sheetRoutesList}>
                      {'Маршруты: '}
                      {selectedStop.routes.slice(0, 12).join(', ')}
                      {selectedStop.routes.length > 12 ? '…' : ''}
                    </Text>
                  )}
                </View>

                {/* Горизонтальная прокрутка прибытий */}
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={styles.arrivalsScroll}
                >
                  <View style={styles.arrivalsRow}>
                    {boardLoading ? (
                      <View style={styles.loadingCard}>
                        <ActivityIndicator color={Colors.orange} />
                        <Text style={styles.noticeText}>Загрузка...</Text>
                      </View>
                    ) : arrivals.length === 0 ? (
                      <View style={styles.loadingCard}>
                        <MaterialCommunityIcons
                          name="clock-outline"
                          size={18}
                          color={Colors.textSecondary}
                        />
                        <Text style={styles.noticeText}>Нет ближайших прибытий</Text>
                      </View>
                    ) : (
                      arrivals.map(arr => {
                        const routeKey = TransportService.normalizeRouteNumber(
                          arr.vehicle.routeNumber,
                        );
                        const rowSelected =
                          highlightedRouteKey !== null &&
                          routeKey === highlightedRouteKey;

                        return (
                          <Pressable
                            key={arr.id}
                            onPress={() =>
                              toggleRouteHighlight(arr.vehicle.routeNumber)
                            }
                            style={({ pressed }) => [
                              styles.arrivalCard,
                              rowSelected && styles.arrivalCardRouteSelected,
                              pressed && styles.arrivalCardPressed,
                            ]}
                          >
                            {/* Иконка транспорта */}
                            <View
                              style={[
                                styles.arrivalIcon,
                                {
                                  backgroundColor:
                                    TransportColors[arr.vehicle.type],
                                },
                              ]}
                            >
                              <MaterialCommunityIcons
                                name={
                                  (TransportIcons[arr.vehicle.type] as any) ||
                                  'bus'
                                }
                                size={20}
                                color="#fff"
                              />
                            </View>

                            {/* Номер маршрута */}
                            <Text style={styles.arrivalRoute}>
                              {' '}
                              ⚡
                              {String(arr.vehicle.routeNumber).trim() || '—'}
                            </Text>

                            {/* Тип */}
                            <Text style={styles.arrivalTypeHint}>
                              {TransportShortLabels[
                                arr.vehicle.type || 'bus'
                              ] || 'авт.'}
                            </Text>

                            {/* Источник данных: realtime / расписание */}
                            {arr.rawType === 'realtime' ? (
                              <View style={styles.realtimeBadge}>
                                <Text style={styles.realtimeBadgeText}>
                                  Live
                                </Text>
                              </View>
                            ) : null}

                            {/* Время до прибытия */}
                            <Text style={styles.arrivalTime}>
                              {(arr.secondsUntilArrival ?? 0) <= 15
                                ? 'Прибывает'
                                : formatEta(arr)}
                            </Text>

                            {/* Заполненность */}
                            <Text
                              style={[
                                styles.arrivalOccupancy,
                                {
                                  color: TransportService.getOccupancyColor(
                                    arr.vehicle.occupancy,
                                  ),
                                },
                              ]}
                            >
                              {TransportService.getOccupancyLabel(
                                arr.vehicle.occupancy,
                              )}
                            </Text>
                          </Pressable>
                        );
                      })
                    )}
                  </View>
                </ScrollView>
              </>
            )}
          </Animated.View>
        </View>
      </Modal>
    </View>
  );
}

// ─── Стили ────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },

  // Топ-бар
  topBar: { position: 'absolute', top: 0, left: 0, right: 0 },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 8,
    gap: 10,
  },
  iconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(26,26,26,0.95)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  pressablePressed: {
    opacity: 0.78,
    transform: [{ scale: 0.94 }],
  },
  appTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(26,26,26,0.95)',
    borderRadius: 22,
    paddingHorizontal: 14,
    height: 44,
  },
  searchInput: { flex: 1, color: '#fff', fontSize: 15 },

  metaRow: {
    marginTop: 8,
    marginHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  noticeCard: {
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(26,26,26,0.95)',
    borderWidth: 0.5,
    borderColor: Colors.separator,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  noticeText: {
    color: Colors.textSecondary,
    fontSize: 12,
    fontWeight: '500',
  },

  // Маркеры
  vehicleMarkerWrap: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vehicleRouteHalo: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 3,
    borderColor: Colors.orange,
    opacity: 0.95,
  },
  vehicleMarker: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  vehicleMarkerRouteHighlight: {
    borderColor: Colors.orange,
    borderWidth: 2,
  },
  stopMarker: {
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.4)',
  },
  stopMarkerSelected: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderColor: '#fff',
    borderWidth: 1.5,
  },

  // Нижний лист
  modalRoot: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  sheetOverlayPress: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1,
  },
  sheet: {
    backgroundColor: Colors.card,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderTopWidth: 3,
    borderTopColor: Colors.orange,
    paddingBottom: 32,
    minHeight: 320,
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2,
    shadowColor: Colors.purple,
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 18,
  },
  sheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: Colors.separator,
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 4,
  },
  sheetHeader: {
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
  },
  sheetSubtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  sheetTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 4,
  },
  sheetAddressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 6,
  },
  sheetAddress: { fontSize: 13, color: Colors.textSecondary },
  sheetRoutesList: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },

  // Прибытия
  arrivalsScroll: { marginBottom: 16 },
  arrivalsRow: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
  },
  arrivalCard: {
    backgroundColor: Colors.card2,
    borderRadius: 16,
    padding: 12,
    width: 160,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
  arrivalCardRouteSelected: {
    borderColor: Colors.orange,
    borderWidth: 2,
    backgroundColor: 'rgba(255,107,26,0.12)',
  },
  arrivalCardPressed: {
    opacity: 0.88,
    transform: [{ scale: 0.98 }],
  },
  arrivalIcon: {
    width: 38,
    height: 38,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  arrivalRoute: {
    fontSize: 15,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 2,
  },
  arrivalTypeHint: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '600',
    marginBottom: 2,
  },
  realtimeBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(52,199,89,0.18)',
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
    marginBottom: 4,
  },
  realtimeBadgeText: {
    fontSize: 10,
    color: '#34C759',
    fontWeight: '700',
  },
  arrivalTime: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginBottom: 2,
  },
  arrivalOccupancy: { fontSize: 11, fontWeight: '600' },
  loadingCard: {
    width: 180,
    backgroundColor: Colors.card2,
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderWidth: 0.5,
    borderColor: Colors.separator,
  },
});
